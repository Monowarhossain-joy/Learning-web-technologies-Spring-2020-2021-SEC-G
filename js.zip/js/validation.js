
function validate(){
    let uname=document.getElementById('username').value;
    let email=document.getElementById('email').value;
    let password=document.getElementById('password').value;
    let repass=document.getElementById('repass').value;
    let gender=document.getElementById('gender');
    let dob=document.getElementById('dob').value;

    unameCheck();
    mailCheck();
    passwordCheck();
    genderCheck();
    dobCheck();
	
 function unameCheck(){
            if(uname=="") {
                document.getElementById('msg1').innerHTML="**name cannot be empty";
            }
            else{
                
			}  
        }

    
    function mailCheck(){
        if(email==""){
            document.getElementById('msg4').innerHTML="**email cannot be empty";
        }
        else{
            if (email.includes("@") && email.includes(".com")) {
            }
            else{
                document.getElementById('msg4').innerHTML="**not a valid email";
            }
        }
    }
    function passwordCheck(){
        if(password==""){
            document.getElementById('msg8').innerHTML="**password cannot be empty";
        }
        if(repass==""){
            document.getElementById('msg9').innerHTML="**confirm_pass cannot be empty";
        }
        else{
            if(password!=repass){
                document.getElementById('msg9').innerHTML="**please check your password and confirm password";
				
				window.location = "login.html";
				//abc = false;
            }
        }
    }
    function genderCheck(){
        if(gender==""){
            document.getElementById('msg10').innerHTML="**gender cannot be empty";
			//abc = false;
        }
    }

    function dobCheck(){
        if(dob==""){
            document.getElementById('msg11').innerHTML="**Date of Birth cannot be empty";
			//abc = false;
        }
    }
	if (!(validate())){
		
		window.location = "login.html";
	}
	else{
		
	}


}

